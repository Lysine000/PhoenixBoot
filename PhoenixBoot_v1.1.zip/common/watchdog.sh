#!/system/bin/sh
# PhoenixBoot v4 Watchdog
# Protects against Android framework bootloops.
# Self-destructs after confirmed boot or after restoring backup.
# No external dependencies.

ORIG_BOOT="/data/local/tmp/boot_orig.img"
ORIG_HASH="/data/local/tmp/boot_orig.sha1"
BOOT_PART="BOOT_PART_PLACEHOLDER"
MY_PATH="SERVICE_DIR_PLACEHOLDER/phoenixboot_watchdog.sh"

# 15 minutes max — covers OTA Dalvik/ART rebuild and first boot after wipe
# 90 checks x 10 seconds = 900 seconds = 15 minutes
MAX_CHECKS=90
CHECK_INTERVAL=10

(
    # No backup = nothing to protect, self-destruct cleanly
    if [ ! -f "$ORIG_BOOT" ]; then
        rm -f "$MY_PATH"
        exit 0
    fi

    CHECKS=0
    while [ $CHECKS -lt $MAX_CHECKS ]; do

        # SUCCESS: Android fully booted
        if [ "$(getprop sys.boot_completed)" = "1" ]; then
            rm -f "$ORIG_BOOT" "$ORIG_HASH" "$MY_PATH"
            exit 0
        fi

        sleep $CHECK_INTERVAL
        CHECKS=$((CHECKS + 1))
    done

    # BOOTLOOP DETECTED — verify backup integrity before restoring
    if [ -f "$ORIG_HASH" ]; then
        EXPECTED=$(awk '{print $1}' "$ORIG_HASH")
        ACTUAL=$(sha1sum "$ORIG_BOOT" | awk '{print $1}')
        if [ "$EXPECTED" != "$ACTUAL" ]; then
            # Backup is corrupt — do NOT flash, reboot to recovery
            rm -f "$ORIG_BOOT" "$ORIG_HASH" "$MY_PATH"
            /system/bin/reboot recovery
            exit 1
        fi
    fi

    # Backup verified — restore original boot image
    dd if="$ORIG_BOOT" of="$BOOT_PART"
    rm -f "$ORIG_BOOT" "$ORIG_HASH" "$MY_PATH"

    # Reboot to recovery so user can see what happened
    /system/bin/reboot recovery

) &
